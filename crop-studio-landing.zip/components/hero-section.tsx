import { Button } from "@/components/ui/button"
import { InteractiveGrid } from "@/components/ui/interactive-grid"
import { ShineBorder } from "@/components/ui/shine-border"
import { ArrowRight, Play } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative min-h-screen pt-32 pb-16 overflow-hidden bg-[#0f172a]">
      <InteractiveGrid containerClassName="absolute inset-0" className="opacity-30" points={40} />

      <ShineBorder
        className="relative z-10 max-w-6xl mx-auto px-6"
        borderClassName="border border-white/10 rounded-xl overflow-hidden"
      >
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 tracking-tight">
            Potencia tu Presencia Digital
            <br />
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-600">
              con Estrategias Efectivas
            </span>
          </h1>
          <p className="text-gray-400 text-lg mb-8 max-w-2xl mx-auto">
            Especialistas en paid media y desarrollo web que transforman tu visión en resultados medibles. Diseñamos
            estrategias personalizadas para maximizar tu ROI y alcanzar tus objetivos de negocio.
          </p>
          <div className="flex gap-4 justify-center">
            <Button variant="outline" className="gap-2 border-white/10 bg-white/5 hover:bg-white/10">
              <Play className="w-4 h-4" />
              Ver Casos
            </Button>
            <Button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:opacity-90">
              Solicitar Propuesta
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>

        <ShineBorder className="relative mx-auto" borderClassName="border border-white/10 rounded-xl overflow-hidden">
          <div className="relative">
            <div className="w-full h-[600px] bg-gradient-to-b from-blue-900/20 to-purple-900/20"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="bg-black/30 backdrop-blur-sm p-6 rounded-xl w-[90%] h-[80%] flex flex-col md:flex-row gap-6">
                <div className="flex-1 rounded-lg overflow-hidden">
                  <div className="h-full bg-gradient-to-br from-blue-900/40 to-purple-900/40 p-6 flex flex-col">
                    <h3 className="text-2xl font-bold mb-4 text-white">Paid Media</h3>
                    <p className="text-gray-300 mb-6">
                      Campañas optimizadas en Google Ads, Facebook, Instagram y LinkedIn que maximizan tu inversión
                      publicitaria.
                    </p>
                    <div className="mt-auto flex justify-between items-center">
                      <span className="text-sm text-blue-300">Conversión promedio +45%</span>
                      <Button variant="outline" size="sm" className="border-white/20 hover:bg-white/10">
                        Más información
                      </Button>
                    </div>
                  </div>
                </div>
                <div className="flex-1 rounded-lg overflow-hidden">
                  <div className="h-full bg-gradient-to-br from-purple-900/40 to-blue-900/40 p-6 flex flex-col">
                    <h3 className="text-2xl font-bold mb-4 text-white">Desarrollo Web</h3>
                    <p className="text-gray-300 mb-6">
                      Sitios web y aplicaciones a medida con diseño UX/UI centrado en la conversión y optimizados para
                      SEO.
                    </p>
                    <div className="mt-auto flex justify-between items-center">
                      <span className="text-sm text-purple-300">Velocidad de carga +80%</span>
                      <Button variant="outline" size="sm" className="border-white/20 hover:bg-white/10">
                        Ver proyectos
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </ShineBorder>
      </ShineBorder>
    </section>
  )
}

