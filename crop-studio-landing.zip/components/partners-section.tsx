import { Marquee } from "@/components/ui/marquee"

export function PartnersSection() {
  const partners = [
    { name: "Google Partner", width: 120 },
    { name: "Meta Business Partner", width: 140 },
    { name: "HubSpot Partner", width: 120 },
    { name: "AWS Partner", width: 100 },
    { name: "Shopify Partner", width: 120 },
    { name: "LinkedIn Partner", width: 130 },
  ]

  return (
    <section className="py-16">
      <div className="max-w-6xl mx-auto mb-8">
        <h3 className="text-xl font-medium text-center text-gray-400">Certificados y Partners</h3>
      </div>
      <Marquee pauseOnHover speed={30}>
        {partners.map((partner) => (
          <div key={partner.name} className="flex items-center justify-center w-48 h-16">
            <div className="flex items-center justify-center px-6 py-3 bg-white/5 rounded-lg border border-white/10">
              <span className="text-gray-300 font-medium">{partner.name}</span>
            </div>
          </div>
        ))}
      </Marquee>
    </section>
  )
}

