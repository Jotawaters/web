import { Button } from "@/components/ui/button"
import { ShineBorder } from "@/components/ui/shine-border"
import { ArrowRight } from "lucide-react"

export function CTASection() {
  return (
    <section className="py-16 px-6" id="contact">
      <div className="max-w-4xl mx-auto">
        <ShineBorder className="relative" borderClassName="border border-white/10 rounded-xl overflow-hidden">
          <div className="p-8 md:p-12 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">¿Listo para potenciar tu presencia digital?</h2>
            <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
              Agenda una consulta gratuita con nuestros especialistas y descubre cómo podemos ayudarte a alcanzar tus
              objetivos de negocio.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:opacity-90">
                Solicitar propuesta
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button variant="outline" className="border-white/10 bg-white/5 hover:bg-white/10">
                Ver planes y precios
              </Button>
            </div>
          </div>
        </ShineBorder>
      </div>
    </section>
  )
}

