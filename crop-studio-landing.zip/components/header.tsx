import Link from "next/link"
import { Button } from "@/components/ui/button"

export function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      <div className="flex items-center justify-between px-6 py-4 backdrop-blur-xl bg-[#0f172a]/50">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-md bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold">
              K
            </div>
            <span className="font-medium text-white">KONCEPTO STUDIO</span>
          </Link>
        </div>
        <nav className="hidden md:flex items-center gap-8">
          <Link href="#services" className="text-sm text-gray-300 hover:text-white transition-colors">
            Servicios
          </Link>
          <Link href="#portfolio" className="text-sm text-gray-300 hover:text-white transition-colors">
            Portfolio
          </Link>
          <Link href="#process" className="text-sm text-gray-300 hover:text-white transition-colors">
            Proceso
          </Link>
          <Link href="#pricing" className="text-sm text-gray-300 hover:text-white transition-colors">
            Precios
          </Link>
          <Link href="#contact" className="text-sm text-gray-300 hover:text-white transition-colors">
            Contacto
          </Link>
        </nav>
        <Button variant="secondary" className="bg-white text-[#0f172a] hover:bg-gray-100">
          Contáctanos
        </Button>
      </div>
    </header>
  )
}

