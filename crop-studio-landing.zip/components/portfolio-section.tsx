import { ShineBorder } from "@/components/ui/shine-border"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function PortfolioSection() {
  const projects = [
    {
      title: "E-commerce Premium",
      category: "Desarrollo Web + Paid Media",
      description: "Incremento de ventas del 120% en 6 meses con estrategia omnicanal",
    },
    {
      title: "App Fintech",
      category: "Desarrollo Web + UX/UI",
      description: "Rediseño que mejoró la tasa de conversión en un 45%",
    },
    {
      title: "Campaña Inmobiliaria",
      category: "Paid Media + Analytics",
      description: "Reducción del 35% en coste por lead cualificado",
    },
    {
      title: "Plataforma SaaS",
      category: "Desarrollo Web + SEO",
      description: "Aumento del 80% en tráfico orgánico tras migración",
    },
  ]

  return (
    <section className="py-16 px-6" id="portfolio">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-4 text-center bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400">
          Proyectos Destacados
        </h2>
        <p className="text-gray-400 text-center mb-12 max-w-2xl mx-auto">
          Casos de éxito que demuestran nuestro enfoque orientado a resultados y nuestra capacidad para transformar
          negocios digitalmente.
        </p>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <ShineBorder
              key={index}
              className="h-full"
              borderClassName="border border-white/10 rounded-xl overflow-hidden"
            >
              <div className="p-6 h-full flex flex-col">
                <div className="mb-4">
                  <span className="text-sm font-medium text-blue-400">{project.category}</span>
                  <h3 className="text-xl font-bold mt-2">{project.title}</h3>
                </div>
                <div className="flex-1">
                  <div className="w-full h-48 bg-gradient-to-br from-blue-900/20 to-purple-900/20 rounded-lg mb-4"></div>
                  <p className="text-gray-400">{project.description}</p>
                </div>
                <Button variant="link" className="mt-4 p-0 text-blue-400 hover:text-blue-300 justify-start">
                  Ver caso completo <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </ShineBorder>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:opacity-90">
            Ver todos los proyectos
          </Button>
        </div>
      </div>
    </section>
  )
}

