import { GradientCard } from "@/components/ui/gradient-card"

export function ProcessSection() {
  const steps = [
    {
      number: "01",
      title: "Descubrimiento",
      description: "Analizamos tu negocio, competencia y objetivos para crear una estrategia personalizada.",
    },
    {
      number: "02",
      title: "Estrategia",
      description: "Definimos el plan de acción, canales, presupuestos y KPIs para maximizar resultados.",
    },
    {
      number: "03",
      title: "Implementación",
      description: "Desarrollamos tu web y configuramos tus campañas con las mejores prácticas del sector.",
    },
    {
      number: "04",
      title: "Optimización",
      description: "Analizamos datos continuamente para mejorar el rendimiento y escalar los resultados.",
    },
  ]

  return (
    <section className="py-16 px-6 bg-gradient-to-b from-[#0f172a] to-[#1e293b]" id="process">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-4 text-center bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400">
          Nuestro Proceso
        </h2>
        <p className="text-gray-400 text-center mb-12 max-w-2xl mx-auto">
          Metodología probada que garantiza resultados predecibles y escalables para tu negocio digital.
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step) => (
            <GradientCard key={step.number} className="h-full">
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold mb-4">
                {step.number}
              </div>
              <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
              <p className="text-gray-400">{step.description}</p>
            </GradientCard>
          ))}
        </div>
      </div>
    </section>
  )
}

