import { GradientCard } from "@/components/ui/gradient-card"
import { Zap, Code, BarChart3, Users, Search, Rocket } from "lucide-react"

export function FeaturesSection() {
  const features = [
    {
      title: "Paid Media",
      description: "Campañas publicitarias optimizadas para maximizar tu ROI en todas las plataformas",
      icon: <Zap className="w-10 h-10 text-blue-400 mb-4" />,
    },
    {
      title: "Desarrollo Web",
      description: "Sitios web y aplicaciones a medida con tecnologías de vanguardia",
      icon: <Code className="w-10 h-10 text-purple-400 mb-4" />,
    },
    {
      title: "Analítica Avanzada",
      description: "Medición precisa de resultados para optimizar continuamente tus campañas",
      icon: <BarChart3 className="w-10 h-10 text-blue-400 mb-4" />,
    },
    {
      title: "UX/UI Design",
      description: "Experiencias de usuario que convierten visitantes en clientes",
      icon: <Users className="w-10 h-10 text-purple-400 mb-4" />,
    },
    {
      title: "SEO Técnico",
      description: "Optimización para buscadores integrada en el desarrollo de tu sitio",
      icon: <Search className="w-10 h-10 text-blue-400 mb-4" />,
    },
    {
      title: "Growth Marketing",
      description: "Estrategias de crecimiento basadas en datos y experimentación",
      icon: <Rocket className="w-10 h-10 text-purple-400 mb-4" />,
    },
  ]

  return (
    <section className="py-16 px-6" id="services">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-4 text-center bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400">
          Nuestros Servicios
        </h2>
        <p className="text-gray-400 text-center mb-12 max-w-2xl mx-auto">
          Combinamos estrategias de paid media con desarrollo web de alto rendimiento para crear soluciones digitales
          completas que impulsan el crecimiento de tu negocio.
        </p>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature) => (
            <GradientCard key={feature.title} className="h-full">
              {feature.icon}
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-400">{feature.description}</p>
            </GradientCard>
          ))}
        </div>
      </div>
    </section>
  )
}

