import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { FeaturesSection } from "@/components/features-section"
import { PartnersSection } from "@/components/partners-section"
import { PortfolioSection } from "@/components/portfolio-section"
import { ProcessSection } from "@/components/process-section"
import { CTASection } from "@/components/cta-section"

export default function Home() {
  return (
    <main className="min-h-screen bg-[#0f172a]">
      <Header />
      <HeroSection />
      <PartnersSection />
      <FeaturesSection />
      <PortfolioSection />
      <ProcessSection />
      <CTASection />
    </main>
  )
}

